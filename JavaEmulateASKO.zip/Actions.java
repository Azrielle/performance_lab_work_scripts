/*
 * LoadRunner Java script. (Build: _build_number_)
 * 
 * Script Description: 
 *                     
 */

import lrapi.lr;
import java.sql.*;
public class Actions
{

	public int init() throws Throwable {
		return 0;
	}//end of init


	public int action() throws Throwable {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@192.168.14.53:1522:orcl","c##x5","c##x5");
		if (conn != null)
		{
			System.out.println("Connected to db");
			String query = "select id from ticket where state_id=-1 and rownum=1";
			int id_ticket;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.next()){
				id_ticket = rs.getInt(1);
				System.out.println("---------ID="+Integer.toString(id_ticket));
				query = "Update ticket set state_id=1 where id="+Integer.toString(id_ticket);
				rs = stmt.executeQuery(query);
				query = "insert into task (id,ticket_id,state_id,client_id,guid,header,text,create_date,external_system)"+
				"select id,id,state_id,'106',guid,header,text,create_date,'ASKO' from ticket where id="+Integer.toString(id_ticket);
				rs = stmt.executeQuery(query);
				System.out.println(rs);
			}
		}
		else
		{
			System.out.println("Failed connected to db");
		}
		
		conn.close();
		return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end
}

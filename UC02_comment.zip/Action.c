Action()
{

	lr_start_transaction("UC02_01_filter");

	web_add_cookie("filterSetting="
		"%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22engineer%22%3Anull%2C%22location%22%3Anull%2C%22division%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Afalse%2C%22appointedCheckbox%22%3Afalse%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%2"
		"2%3Afalse%7D%7D; DOMAIN=192.168.14.54");
	/*

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	lr_think_time(3);

	
	web_reg_save_param_json(
        "ParamName=JSON_task_id",
        "QueryString=$.content.[*].taskId",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_custom_request("ticket_2", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		EXTRARES, 
		"Url=/engineer/ticket/ticket.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/engineer/ticket/ticket.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/images/logo-5ka.png", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);

	lr_end_transaction("UC02_01_filter",LR_AUTO);

	lr_save_string(lr_paramarr_random("JSON_task_id"),"random_task_id");
	lr_start_transaction("UC02_03_click_task");

	web_custom_request("160180", 
		"URL=http://192.168.14.54:9433/api/ticket/{random_task_id}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/images/custom.png", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/tpl/comment.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);

	web_url("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/{random_task_id}/comment/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(3);

	lr_start_transaction("UC02_04_save_comment");

	web_custom_request("comment_2", 
		"URL=http://192.168.14.54:9433/api/ticket/{random_task_id}/comment/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"text\":\"{message_comment}\",\"files\":[]}", 
		LAST);

	web_url("comment_3", 
		"URL=http://192.168.14.54:9433/api/ticket/{random_task_id}/comment/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_log_message(lr_eval_string("{random_task_id}"));
	lr_end_transaction("UC02_04_save_comment",LR_AUTO);

	lr_start_transaction("UC02_05_click_ok");

	lr_end_transaction("UC02_05_click_ok",LR_AUTO);

	lr_end_transaction("UC02_03_click_task",LR_AUTO);

	return 0;
}
Action()
{

	int i,j,array_len,random_idx,error_chek;
	lr_start_transaction("UC01_create_int");

/*	web_add_cookie("filterSetting="
		"%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22engineer%22%3Anull%2C%22location%22%3Anull%2C%22division%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Atrue%2C%22appointedCheckbox%22%3Atrue%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%22%"
		"3Atrue%7D%7D; DOMAIN=192.168.14.54");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	lr_think_time(3);

//	web_url("catalog.dust", 
//		"URL=http://192.168.14.54:9433/engineer/catalog/catalog.dust", 
//		"TargetFrame=", 
//		"Resource=1", 
//		"RecContentType=application/octet-stream", 
//		"Referer=http://192.168.14.54:9433/", 
//		"Snapshot=t5.inf", 
//		LAST);
//
//	web_url("catalog.js", 
//		"URL=http://192.168.14.54:9433/engineer/catalog/catalog.js", 
//		"TargetFrame=", 
//		"Resource=1", 
//		"RecContentType=application/javascript", 
//		"Referer=http://192.168.14.54:9433/", 
//		"Snapshot=t6.inf", 
//		LAST); 

	
	web_reg_save_param_json(
        "ParamName=JSON_location_adress",
        "QueryString=$.[location]",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_id_adress",
        "QueryString=$..id",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_url("get_JSON_id_adress", 
		"URL=http://192.168.14.54:9433/api/shops?q=&page=0", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t7.inf", 
		LAST);

/*	web_revert_auto_header("X-Requested-With");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,mimojjlkmoijpicakmndhoigimigcmbb,gcmjkmgdlgnkkcocmoeiminaijmmjnii,oimompecagnajdejgnnjijobebaeigek,hnimpnehoodheedghdeeijklkeaacbdc,hfnkpimlhhgieaddgfemjhofmfblmnib,llkgjffcdpffmhiakmfcdcblohccpfmo,khaoiebndkojlmppeemjhbpbandiljpe,giekcmmlnklenlaomppkphknjmnnpneh,aemomkdncapdnfajjbbcbdebjljbpmpj,gkmgaooipdjhmangpemjhigmamcehddo,copjbmjbojbakpaedmpkhmiplmmehfck,ehgidpndbllacpjalkiimkbadgjfnnmc,jflookgnkcckhobaglndicnbbgbonegd,ggkkehgbnfjpeggfpleeakpidbkibbmn,"
		"bklopemakmnopmghhmccadeonafabnal");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-81.0.4044.43"); */

	
       
/*//	web_custom_request("json", 
//		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:2411186374&cup2hreq=3a0ada288cbf4aed30e06620b0f19c140b17385a7d80650ffd3e0d71773bbdec", 
//		"Method=POST", 
//		"TargetFrame=", 
//		"Resource=0", 
//		"RecContentType=application/json", 
//		"Referer=", 
//		"Snapshot=t8.inf", 
//		"Mode=HTML", 
//		"EncType=application/json", 
//		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{2dec34e5-bb1b-4ccd-b45e-603444f31ac5}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"GGLS\",\"cohort\":\"1:d0j/fqf:\",\"cohorthint\":\"Beta\",\"cohortname\":\"Beta\",\"enabled\":true,\""
//		"packages\":{\"package\":[{\"fp\":\"1.836a5a90b448bede995cdbbb251804b24208eacc171d33b84334a8735c33a176\"}]},\"ping\":{\"ping_freshness\":\"{c0f9b391-6c78-441c-8582-9b3f46ddebc0}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"32.0.0.344\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"TenPercent\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
//		"1.715c48ce73b7ee71924470b10e920a4e23cd6f9c860f367d00feaff0d03eb52f\"}]},\"ping\":{\"ping_freshness\":\"{946fea67-581d-459a-bb28-cd8ae5aa5935}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"9.11.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{140d9f8c-3086-4618-a47e-48188b939f29}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"4.10.1610.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"enabled\":true,"
//		"\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{57bad617-9a19-4113-aa87-0cf4c6bd20f1}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.dd65f5a999d486e2c40b273556b6c2c66b20485c7a06c1fe7d6551b34baa934c\""
//		"}]},\"ping\":{\"ping_freshness\":\"{355da0c1-14e5-455f-8086-2a1b2c484776}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"5736\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{bd3a1a63-943a-40bf-948b-962c113099c8}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\""
//		"packages\":{\"package\":[{\"fp\":\"1.5cb8df53fe2b86bf838ea2c9ffc3d5ef8460f679a779ac8aa924b5afffd052cb\"}]},\"ping\":{\"ping_freshness\":\"{5b4ef2af-6d62-4a0b-8581-0ca4b0d04fc7}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"42\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\""
//		":{\"ping_freshness\":\"{2e712580-825f-48c5-af9b-fb54c5becda4}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GGLS\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{6e4af17f-66b1-4a90-9bf5-56acd867cae6}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GGLS\",\"cohort\":\"1:qe3:\",\"cohorthint\":\"Canary\",\"cohortname\":\"Canary\",\"enabled\":true,\"packages\":{\""
//		"package\":[{\"fp\":\"1.4d9ddf151092a9830f94069b96d5f165e9acd31e5372d342d3c1a3bcb8a28262\"}]},\"ping\":{\"ping_freshness\":\"{c5ef2a81-c13e-405a-8356-e38a9e57f2eb}\",\"rd\":4814},\"tag\":\"canary_eset_b\",\"updatecheck\":{},\"version\":\"80.230.200\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"GGLS\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
//		"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\"{75324504-35d6-4e51-b847-3280d3dd9ab0}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"2018.9.6.0\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:off:\",\"cohorthint\":\"beta64\",\"cohortname\":\"beta64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\""
//		"{5cf3c1d3-48e5-4fa4-8e91-c8e01222c220}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.d3927a61e4e2093cc4ce4db943f67586abaac95981c62a51694b2cace33280f4\"}]},\"ping\":{\"ping_freshness\":\"{ee142ac1-c8af-441d-9a56-e296986d1b2e}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"315\"},{\"appid\":\""
//		"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9:\",\"cohorthint\":\"M80ToM89\",\"cohortname\":\"M80ToM89\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.b1f3c285be4dc98e8a50c942beb5927f24c7163ac6c1b24e26902f4bd79bc20e\"}]},\"ping\":{\"ping_freshness\":\"{d6da8af4-534a-4b9b-9821-669540be33cf}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"2020.3.2.1202\"},{\"appid\":\"bklopemakmnopmghhmccadeonafabnal\",\"brand\":\"GGLS\",\"cohort\":\"1:swl:\",\"cohorthint\":\""
//		"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6dce22b9a11fa1e62b22559c4a157ce745e7fc63c6c6941a82cf11e8ecf65b0e\"}]},\"ping\":{\"ping_freshness\":\"{9a0cfc19-61a5-4e8a-b937-222f234147cd}\",\"rd\":4814},\"updatecheck\":{},\"version\":\"3\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"physmemory\":4},\"lang\":\"ru\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"sp\":\"Service Pack 1\",\"version\":\""
//		"6.1.7601.24544\"},\"prodchannel\":\"beta\",\"prodversion\":\"81.0.4044.43\",\"protocol\":\"3.1\",\"requestid\":\"{0591c0a4-b9f0-4967-a92d-180b13221748}\",\"sessionid\":\"{1954c928-c296-4720-b779-1e1bd0ba55ba}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.35.442\"},\"updaterchannel\":\"beta\",\"updaterversion\":\"81.0.4044.43\"}}", 
//		EXTRARES, 
//		"Url=http://192.168.14.54:9433/api/shops?q=&page=0", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/user/catalog/node/0/children/", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/user/catalog/treeview?shopid=4", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/engineer/catalog/catalog.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/engineer/catalog/catalog.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/user/catalog/node/154/children/", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/user/catalog/node/154/service/", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/user/catalog/breadcrumbs/154", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/engineer/addticket.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/inventoryNumbers?serviceId=2818&shopId=4", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=https://dns.google/dns-query?dns=rBcBAAABAAAAAAABDHNhZmVicm93c2luZwpnb29nbGVhcGlzA2NvbQAAAQABAAApEAAAAAAAAEgADABEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
//		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
//		"ChwKDGdvb2dsZWNocm9tZRIMODEuMC40MDQ0LjQzGikIBRABGhsKDQgFEAYYASIDMDAxMAEQ2JYIGgIYCHiorMwiBCABIAIoARopCAEQARobCg0IARAGGAEiAzAwMTABEICNBxoCGAjatIXOIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARDqjwcaAhgIoLeYuyIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQyoEHGgIYCF8gi98iBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgI9uukkyIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQwxkaAhgIEm2uVyIEIAEgAigEGicICRABGhkKDQgJEAYYASIDMDAxMAYQAxoCGAgbLJFNIgQgASACKAYaKAgPEAEaGgoNCA8QBhgBIgMwMDEwARC8JBoCGAgPh9zqIgQgASACKAEaJwgKEAgaGQ"
//		"oNCAoQCBgBIgMwMDEwARAFGgIYCLrBrKMiBCABIAIoARonCAkQARoZCg0ICRAGGAEiAzAwMTABEBkaAhgI47zs7iIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQlggaAhgIB1MvgiIEIAEgAigBGigIDRABGhoKDQgNEAYYASIDMDAxMAEQ0W4aAhgIHfTXWCIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQhJ0DGgIYCNOXZcIiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEM4BGgIYCKYv4M8iBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
//		"Url=http://192.168.14.54:9433/api/inventoryNumbers?shopId=4&serviceId=2818&serviceId=2818&q=&page=0", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		LAST); */
	lr_save_string(lr_paramarr_random("JSON_id_adress"),"random_id_adress");
	web_reg_save_param_json(
        "ParamName=JSON_service_id",
        "QueryString=$..services.[id]",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
       web_reg_save_param_json(
        "ParamName=JSON_service_parent_id",
        "QueryString=$..services.[parentId]",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_service_name",
        "QueryString=$..services.[name]",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_service_parent_name",
        "QueryString=$..services.[parentName]",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_custom_request("get_JSON_service", 
		"Url=http://192.168.14.54:9433/api/user/catalog/treeview?shopid={random_id_adress}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST); 

	random_idx=rand()%lr_paramarr_len("JSON_service_id")+1;
	lr_save_string(lr_paramarr_idx("JSON_service_id",random_idx),"random_service_id");
	lr_save_string(lr_paramarr_idx("JSON_service_parent_id",random_idx),"parent_id_for_service_id");
	lr_save_string(lr_paramarr_idx("JSON_service_name",random_idx),"service_id_name");
	lr_save_string(lr_paramarr_idx("JSON_service_parent_name",random_idx),"service_id_parent_name");
		
	web_reg_save_param_json(
        "ParamName=JSON_inventory_numbers_id",
        "QueryString=$.[id]",
        "SelectAll=yes",
        "Notfound=warning",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_custom_request("get_JSON_inventory_numbers_id", 
		"Url=http://192.168.14.54:9433/api/inventoryNumbers?serviceId={random_service_id}&shopId={random_id_adress}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t999.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST); 




	lr_start_transaction("UC01_01_geo");

	lr_end_transaction("UC01_01_geo",LR_AUTO);

	lr_start_transaction("UC01_02_tema");

	lr_end_transaction("UC01_02_tema",LR_AUTO);

	lr_start_transaction("UC01_03_create_button");

/*	web_add_header("Origin", 
		"http://192.168.14.54:9433");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");*/

	lr_think_time(3);

	if (lr_paramarr_len("JSON_inventory_numbers_id")==0){
		lr_save_string("null","random_inventory_numbers_id_or_null");
	}else{
		lr_save_string(lr_paramarr_random("JSON_inventory_numbers_id"),"random_inventory_numbers_id_or_null");
	}
	web_custom_request("ticket", 
		"URL=http://192.168.14.54:9433/api/ticket/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"text\":\"{service_id_parent_name}\",\"header\":\"{service_id_name}\",\"ticketStateId\":0,\"serviceId\":\"{random_service_id}\",\"files\":[],\"inventoryNumberId\":\"{random_inventory_numbers_id_or_null}\",\"shopId\":\"{random_id_adress}\"}", 
/*//		EXTRARES, 
//		"Url=../checkLogin", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=/js/core/jqueryformplugin.js?_=1583654024776", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=../user/info", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=/engineer/wrapper/wrapper.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=/engineer/wrapper/wrapper.js", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);

	lr_end_transaction("UC01_03_create_button",LR_AUTO);

	lr_start_transaction("UC01_04_click_ok");

/*//	web_url("4_2", 
//		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
//		"TargetFrame=", 
//		"Resource=0", 
//		"Referer=http://192.168.14.54:9433/", 
//		"Snapshot=t10.inf", 
//		"Mode=HTML", 
//		EXTRARES, 
//		"Url=/engineer/tickets/tickets.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=/engineer/tickets/tickets.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		"Url=../?state=-1,0,1,5&page=0&size=10", "Referer=http://192.168.14.54:9433/", ENDITEM, 
//		LAST); */

	lr_end_transaction("UC01_04_click_ok",LR_AUTO);

	lr_end_transaction("UC01_create_int",LR_AUTO);

	return 0;
}

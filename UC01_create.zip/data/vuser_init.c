/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1203
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_add_cookie("currentCompany=0; DOMAIN=192.168.14.54");

	web_add_cookie("currentUser=engineer_10; DOMAIN=192.168.14.54");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login", 
		"URL=http://192.168.14.54:9433/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=beta&milestone=81", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dns.google/dns-query?dns=5uABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=ga8BAAABAAAAAAABD2R0ZHVob3Vwem5haXVhbgtsb2NhbGRvbWFpbgAAAQABAAApEAAAAAAAAEgADABEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=OkcBAAABAAAAAAABCWVmcWppeXhjagtsb2NhbGRvbWFpbgAAAQABAAApEAAAAAAAAE4ADABKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=pZMBAAABAAAAAAABD3l5dHBmdHVoZ3hib2pvdQtsb2NhbGRvbWFpbgAAAQABAAApEAAAAAAAAEgADABEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("UC01_login");

	web_add_cookie("currentUser=engineer_5; DOMAIN=192.168.14.54");

	web_add_cookie("PFLB.pre.login.link=null; DOMAIN=192.168.14.54");

	web_add_header("Origin", 
		"http://192.168.14.54:9433");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(25);

	web_submit_data("login_2", 
		"Action=http://192.168.14.54:9433/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=engineer_5", ENDITEM, 
		"Name=password", "Value=123", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM, 
		EXTRARES, 
		"Url=../js/core/jqueryformplugin.js?_=1583653869461", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=checkLogin", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=user/info", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=../engineer/wrapper/wrapper.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=../engineer/wrapper/wrapper.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);

	web_url("4", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/engineer/tickets/tickets.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=../?state=-1,0,1,5&page=0&size=10", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_login",LR_AUTO);

	return 0;
}
